<?php 
	$host="localhost";
	$username="root";
	$pass="";
	$database="inventory";
	$koneksi=mysqli_connect($host,$username,$pass,$database) or die ("Gak konek");
?>